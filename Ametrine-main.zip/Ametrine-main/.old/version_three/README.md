# Ametrine Website Repository
The official Ametrine Website Repository

Ametrine Gradient: linear-gradient(135deg, #a259f7 0%, #0071e3 100%);

## Rules:
- Be respectful and professional in all contributions
- Follow the existing code style and formatting conventions
- Test your changes before submitting pull requests
- Write clear, descriptive commit messages
- Document any new features or significant changes
- Report issues with detailed information and reproduction steps

## Links:
- Ko-Fi https://ko-fi.com/ametrinefoundation

## Astro Starter Kit: Minimal

The Ametrine gradient (#a259f7 #0071e3)

```sh
npm create astro@latest -- --template minimal
```

> 🧑‍🚀 **Seasoned astronaut?** Delete this file. Have fun!

## 🚀 Project Structure

Inside of your Astro project, you'll see the following folders and files:

```text
/
├── public/
├── src/
│   └── pages/
│       └── index.astro
└── package.json
```

Astro looks for `.astro` or `.md` files in the `src/pages/` directory. Each page is exposed as a route based on its file name.

There's nothing special about `src/components/`, but that's where we like to put any Astro/React/Vue/Svelte/Preact components.

Any static assets, like images, can be placed in the `public/` directory.

## 🧞 Commands

All commands are run from the root of the project, from a terminal:

| Command                   | Action                                           |
| :------------------------ | :----------------------------------------------- |
| `npm install`             | Installs dependencies                            |
| `npm run dev`             | Starts local dev server at `localhost:4321`      |
| `npm run build`           | Build your production site to `./dist/`          |
| `npm run preview`         | Preview your build locally, before deploying     |
| `npm run astro ...`       | Run CLI commands like `astro add`, `astro check` |
| `npm run astro -- --help` | Get help using the Astro CLI                     |
| `npx @astrojs/upgrade`    | Upgrade your Astro version to the latest         |
